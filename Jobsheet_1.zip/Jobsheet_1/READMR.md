|  | Algorithm and Data Structure |
|--|--|
| NIM |  244107020023|
| Nama |  Dewi Chalissa Rania |
| Kelas | TI - 1I |
| Repository | [link] (https://github.com/jti-polinema/-01-contoh-laporan-react) |

# Labs #1 Programming Fundamentals Review

## 2.1.1. Selection Solution

The solution is implemented in Pemilihan1.java, and below is screenshot of the result.

![Screenshot](lab1.png)

*Brief explanaton:* There are 4 main step: 
1. Input all grades
2. Validate the input
3. Calculate and convert the final grade
4. Decide the final status

## 2.1.1. Looping Solution
The solution is implemented in Pemilihan1.java, and below is screenshot of the result.

![Screenshot](lab1.png)

*Brief explanaton:* There are 4 main step: 
1. Input NIM
2. Validate the input
3. Calculate and convert the final grade
4. Decide the final status